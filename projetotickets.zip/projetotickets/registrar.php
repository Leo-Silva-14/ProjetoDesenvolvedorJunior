<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Ticket de Refeição</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Registrar Entrega de Ticket de Refeição</h1>
    <form method="POST">
        <label for="funcionario_id">Funcionário:</label>
        <select id="funcionario_id" name="funcionario_id" required>
            <?php
            include 'db.php';
            $res = $conn->query("SELECT * FROM funcionarios");
            while ($row = $res->fetch_assoc()) {
                echo "<option value='{$row['id']}'>{$row['nome']}</option>";
            }
            ?>
        </select>
        <button type="submit">Registrar Ticket</button>
    </form>
    <a href="inicio.php">Voltar ao Início</a>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        include 'db.php';
        $id = $_POST['funcionario_id'];
        $sql = "INSERT INTO tickets (funcionario_id) VALUES ($id)";
        if ($conn->query($sql)) {
            echo "<p>Ticket registrado com sucesso!</p>";
        } else {
            echo "<p>Erro: " . $conn->error . "</p>";
        }
    }
    ?>
</body>
</html>