<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Controle de Tickets</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Bem-vindo ao Sistema de Controle de Tickets de Refeição</h1>
    <ul>
        <li><a href="cadastrar.php">Cadastrar Funcionário</a></li>
        <li><a href="registrar.php">Registrar Ticket de Refeição</a></li>
        <li><a href="visualizar.php">Visualizar Relatórios de Tickets</a></li>
    </ul>
</body>
</html>