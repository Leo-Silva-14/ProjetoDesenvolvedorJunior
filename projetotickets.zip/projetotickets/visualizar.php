<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizar Relatórios de Tickets</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Relatório de Tickets Entregues</h1>

    <h2>Total de Tickets por Funcionário</h2>
    <table>
        <tr>
            <th>Funcionário</th>
            <th>Total de Tickets</th>
        </tr>
        <?php
        include 'db.php';
        $sql = "
            SELECT f.nome, COUNT(t.id) as total
            FROM funcionarios f
            LEFT JOIN tickets t ON f.id = t.funcionario_id
            GROUP BY f.id
        ";
        $res = $conn->query($sql);
        while ($row = $res->fetch_assoc()) {
            echo "<tr><td>{$row['nome']}</td><td>{$row['total']}</td></tr>";
        }
        ?>
    </table>

    <h2>Total Geral de Tickets</h2>
    <?php
    $res = $conn->query("SELECT COUNT(*) as total FROM tickets");
    $row = $res->fetch_assoc();
    echo "<p>Total de Tickets Entregues: <strong>{$row['total']}</strong></p>";
    ?>

    <a href="inicio.php">Voltar ao Início</a>
</body>
</html>